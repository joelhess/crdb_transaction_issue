from app.db import Database
from app.organizations_models import Organization

from sqlalchemy_cockroachdb import run_transaction


def main():
    db = setup_db()
    session = db.get_db_session()

    run_transaction(session, lambda s: create_organization(session=session))
    run_transaction(session, lambda s: create_organization(session=session))


def create_organization(session):
    organization = Organization(name="Test Org", label="Test Org Label")
    session.add(organization)
    session.flush()
    return organization
    

def setup_db():
    database_url = "localhost:26257/roach"
    database_user = "cockroach"
    database_password = "arthropod"

    db = Database(
        database_url=database_url,
        database_user=database_user,
        database_password=database_password,
    )

    db.init_connection()
    db.create_database()

    return db

if __name__ == "__main__":
    main()
