"""Provides the db connection."""

import logging
from typing import Optional

import structlog
from sqlalchemy import create_engine
from sqlalchemy.future import Engine
from sqlalchemy.orm import sessionmaker

from .base_models import BaseSQLModel

logger = structlog.get_logger(__name__)


class Database:
    """Database class."""

    def __init__(self, database_url, database_user, database_password) -> None:
        """Init DB properties."""
        self._db_url = database_url
        self._db_user = database_user
        self._db_password = database_password
        self.engine: Optional[Engine] = None
        # self.init_connection()

    def init_connection(self) -> Engine:
        """Init DB connection."""
        try:
            logger.info("Initializing database connection...")
            self.engine = create_engine(
                f"cockroachdb://{self._db_user}:{self._db_password}@{self._db_url}",
                echo=logger.getEffectiveLevel() == logging.DEBUG,
            )
            logger.info("Initializing database connection...DONE")
            return self.engine
        except Exception as connection_error:
            logger.error("Initializing database connection...FAIL")
            raise

    def create_database(self) -> None:
        """Create all tables."""
        logger.info("Creating all tables...")
        BaseSQLModel.metadata.create_all(self._engine)  # type: ignore
        logger.info("Create all tables DONE")

    def delete_all_tables(self) -> None:
        """Delete all tables."""
        logger.info("Deleting all tables...")
        BaseSQLModel.metadata.drop_all(self._engine)  # type: ignore
        logger.info("Delete all tables DONE")

    def get_db_session(self) -> sessionmaker:
        db_engine = self.engine
        session_local = sessionmaker(bind=db_engine)
        return session_local